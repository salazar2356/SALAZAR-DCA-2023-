const data = [
    {
        tittle: "Gimme What I Want",
        artist: "Miley Cyrus",
        img: "./miley.jpg",
    },
    {
        tittle: "Cross Me",
        artist: "Ed Sheeran",
        img: "./ed.jpg",
    },
    {
        tittle: "As It Was",
        artist: "Harry Styles",
        img: "./harry.webp",
    },
    {
        tittle: "Nico And The Niners",
        artist: "Twenty One Pilots",
        img: "./trench.png",
    },
    {
        tittle: "Cry Baby",
        artist: "Melanie Martinez",
        img: "./melanie.png",
    },
    {
        tittle: "Miss You",
        artist: "Oliver Tree",
        img: "./oliver.jpg",
    },
    {
        tittle: "Too Good At Goodbyes",
        artist: "Sam Smith",
        img: "./sam.jpg",
    },
    {
        tittle: "Look At Her Now",
        artist: "Selena Gomez",
        img: "./selena.webp",
    },
    {
        tittle: "River",
        artist: "Miley Cyrus",
        img: "./miley2.jpg",
    },
    {
        tittle: "Baby Boy",
        artist: "Beyoncé",
        img: "./beyonce.jpg",
    },
];
export default data;
