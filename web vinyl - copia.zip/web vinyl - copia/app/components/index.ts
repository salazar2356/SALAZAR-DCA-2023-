export { default as Profile } from "./Profile/profile.js";
export { default as MyNav } from "./Nav/nav.js";

